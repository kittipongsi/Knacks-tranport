const root=document.getElementById("root");
root.innerHTML="<h1>Hello React on Netlify 🎉</h1><p>This site is deployed with Netlify.</p>";