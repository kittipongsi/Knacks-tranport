import React, { useState } from 'react';

export default function App() {
  const [jobs, setJobs] = useState([]);
  const [form, setForm] = useState({
    car: '',
    startDate: '',
    endDate: '',
    pickupTime: '',
    dropTime: '',
    income: '',
    expense: ''
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setJobs([...jobs, form]);
    setForm({
      car: '',
      startDate: '',
      endDate: '',
      pickupTime: '',
      dropTime: '',
      income: '',
      expense: ''
    });
  };

  const totalIncome = jobs.reduce((acc, job) => acc + Number(job.income), 0);
  const totalExpense = jobs.reduce((acc, job) => acc + Number(job.expense), 0);
  const tax = totalIncome * 0.07;
  const net = totalIncome - totalExpense - tax;

  return (
    <div style={{ padding: 20, fontFamily: 'Arial' }}>
      <h1>🚐 Fleet Management</h1>
      <form onSubmit={handleSubmit} style={{ marginBottom: 20 }}>
        <input name="car" placeholder="รถคันที่" value={form.car} onChange={handleChange} required />
        <input type="date" name="startDate" value={form.startDate} onChange={handleChange} required />
        <input type="date" name="endDate" value={form.endDate} onChange={handleChange} required />
        <input type="time" name="pickupTime" value={form.pickupTime} onChange={handleChange} required />
        <input type="time" name="dropTime" value={form.dropTime} onChange={handleChange} required />
        <input type="number" name="income" placeholder="รายรับ" value={form.income} onChange={handleChange} required />
        <input type="number" name="expense" placeholder="รายจ่าย" value={form.expense} onChange={handleChange} required />
        <button type="submit">บันทึก</button>
      </form>

      <h2>📋 ตารางงาน</h2>
      <table border="1" cellPadding="5" style={{ borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            <th>รถ</th>
            <th>วันที่เริ่ม</th>
            <th>วันที่สิ้นสุด</th>
            <th>รับแขก</th>
            <th>ส่งแขก</th>
            <th>รายรับ</th>
            <th>รายจ่าย</th>
          </tr>
        </thead>
        <tbody>
          {jobs.map((job, idx) => (
            <tr key={idx}>
              <td>{job.car}</td>
              <td>{job.startDate}</td>
              <td>{job.endDate}</td>
              <td>{job.pickupTime}</td>
              <td>{job.dropTime}</td>
              <td>{job.income}</td>
              <td>{job.expense}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>📊 สรุป</h2>
      <p>รายรับรวม: {totalIncome} บาท</p>
      <p>รายจ่ายรวม: {totalExpense} บาท</p>
      <p>ภาษี (7%): {tax} บาท</p>
      <p>กำไรสุทธิ: {net} บาท</p>
    </div>
  );
}